package com.study.domain.auction;

import com.study.domain.post.PostResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@RequiredArgsConstructor
public class AuctionService {

    private final AuctionMapper auctionMapper;

    public AuctionResponse findAuctionById(final Long userId) {
                return auctionMapper.findById(userId);
    }



    //    경매
    @Transactional
    public Long savePrice(final AuctionRequest params) {
        auctionMapper.save(params);
        return params.getAuctionId();
    }

//    /**
//     * 게시글 상세정보 조회
//     * @param id - PK
//     * @return 게시글 상세정보
//     */
//    public AuctionResponse findPostById(final Long id) {
//        return postMapper.findById(id);
//    }
//
    /**
     * 게시글 수정
     * @param params - 게시글 정보
     * @return PK
     */
    @Transactional
    public Long updatePrice(final AuctionRequest params) {
        auctionMapper.update(params);
        return params.getAuctionId();
    }
//
//    /**
//     * 게시글 삭제
//     * @param id - PK
//     * @return PK
//     */
//    public Long deletePost(final Long id) {
//        postMapper.deleteById(id);
//        return id;
//    }
//
//    /**
//     * 게시글 리스트 조회
//     * @return 게시글 리스트
//     */
    public List<AuctionResponse> findAllPost() {
        return auctionMapper.findAll();
    }


}
