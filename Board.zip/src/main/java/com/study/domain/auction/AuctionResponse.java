package com.study.domain.auction;

import lombok.Getter;

import java.time.LocalDateTime;

@Getter
public class AuctionResponse {

    private Long auctionPriceId;
    private Long userId;
    private Long auctionId;
    private int biddingPrice;
    private boolean status;
    private LocalDateTime biddingDate;
}
