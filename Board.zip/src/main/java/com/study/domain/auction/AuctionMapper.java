package com.study.domain.auction;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AuctionMapper {

//    경매
   // void save(AuctionRequest params);

    void update(AuctionRequest params);

    void save(AuctionRequest params);


   AuctionResponse findById(final Long userId);
//
//    /**
//     * 게시글 수정
//     * @param params - 게시글 정보
//     */
//    void update(AuctionRequest params);
//
//    /**
//     * 게시글 삭제
//     * @param id - PK
//     */
//    void deleteById(Long id);
//
//    /**
//     * 게시글 리스트 조회
//     * @return 게시글 리스트
//     */
    List<AuctionResponse> findAll();
//
//    /**
//     * 게시글 수 카운팅
//     * @return 게시글 수
//     */
//    int count();

}
