package com.study.domain.auction;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class AuctionRequest {

    private Long auctionPriceId;
    private Long userId;
    private Long auctionId;
    private int biddingPrice;
    private boolean status;
    private LocalDateTime biddingDate;

}
