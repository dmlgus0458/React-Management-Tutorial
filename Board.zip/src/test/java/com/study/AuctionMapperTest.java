package com.study;

import com.study.domain.auction.AuctionMapper;
import com.study.domain.auction.AuctionRequest;
import com.study.domain.auction.AuctionResponse;
import com.study.domain.post.PostRequest;
import com.study.domain.post.PostResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class AuctionMapperTest {

    @Autowired
    AuctionMapper auctionMapper;

//        @Test
//        void save() {
//        AuctionRequest params = new AuctionRequest();
//        params.setUserId(1);
//        params.setAuctionId(4);
//        params.setBiddingPrice(12100);
//        params.setStatus(true);
//        auctionMapper.save(params);
//
//        List<AuctionResponse> posts = auctionMapper.findAll();
//        System.out.println("전체 게시글 개수는 : " + posts.size() + "개입니다.");
//    }
            @Test
        void save() {
        AuctionRequest params = new AuctionRequest();
        params.setUserId(1);
        params.setAuctionId(4);
        params.setBiddingPrice(12100);
        params.setStatus(true);
        params.setAuctionPriceId(4);
        params.setUserId(1);
        params.setBiddingPrice(1557);
        params.setStatus(false);
        auctionMapper.save(params);

        List<AuctionResponse> posts = auctionMapper.findAll();
        System.out.println("전체 게시글 개수는 : " + posts.size() + "개입니다.");
    }

            @Test
        void update() {
        // 1. 게시글 수정
        AuctionRequest params = new AuctionRequest();
        params.setAuctionPriceId(4);
        params.setUserId(1);
        params.setBiddingPrice(1557);
        params.setStatus(false);
        auctionMapper.update(params);

    }
}
